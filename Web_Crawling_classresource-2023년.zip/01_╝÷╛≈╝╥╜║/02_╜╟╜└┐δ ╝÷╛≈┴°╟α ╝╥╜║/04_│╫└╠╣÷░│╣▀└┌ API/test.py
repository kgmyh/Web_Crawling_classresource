# 디렉토리(폴더) 만들기. => os 패키지.
import os
#디렉토리 인지 여부.
# r = os.path.isdir("c:\\aaa") 
# print('c:\\aaa 가 디렉토리?', r)
# r = os.path.isdir('c:\\tmp')
# print('c:\\tmp?', r)

# print(os.path.isfile('./test.py'))

# c:\\tmp - 절대경로.  
# ./test.py  -상대경로. => 현재 디렉토리에서 부터 찾는 방식.

# 디렉토리 생성.
# os.mkdir('./test_dir')


import time
print("----------------------------------")
time.sleep(3)# 3초 동안 멈춰라.
print("##################################")