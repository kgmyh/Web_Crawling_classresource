목적 : open api 사용
       json 처리
       
1. get_naver_news_01.py
    - 뉴스 검색 예제
2. get_naver_news_02.py
    - 페이징 처리
    - start 에서 display 만큼 더해가면서 가져온다. start는 1000이상이 지원하지 않는다.
    - 만약 3번을 수업에서 할 꺼면 스포츠는 가져오지 않는다. 상세 페이지의 구조가 다르다. (뭔가 처리 필요)
3. get_naver_news_03.py
    - 2에서 조회한 목록으로 뉴스 상세 조회
    