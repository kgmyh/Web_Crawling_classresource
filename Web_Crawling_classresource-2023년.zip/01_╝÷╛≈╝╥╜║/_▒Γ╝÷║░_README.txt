EC12기 - 2023/03: 2 - 3일

크롤링
이론: 
1. beatiful soup
2. requests
	- 다음 뉴스읽기
	- naver 주식 (2023실습-request_aiohttp)
3. aysyncio/aiohttp
	- 다음 뉴스읽기: 목록 가져와서
	- naver주식 (2023실습-request_aiohttp)
4. selenium
	- pixabay: 이미지 뜨는 것. fordden (403) 그래서 selenuim으로 (또는 트립어드바이저 식당 댓글 수집)
	- 유튜브 무한 스크롤