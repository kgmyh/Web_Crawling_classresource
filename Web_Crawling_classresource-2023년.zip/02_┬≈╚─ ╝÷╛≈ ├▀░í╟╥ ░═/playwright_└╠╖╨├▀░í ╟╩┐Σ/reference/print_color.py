print('\033[95m' + '1.안녕' + '\033[0m') 
print('\x1b[31m' + '2.안녕' + '\x1b[0m') 
print('\u001b[0m' + '3.안녕' + '\u001b[0m')

# https://sosomemo.tistory.com/59